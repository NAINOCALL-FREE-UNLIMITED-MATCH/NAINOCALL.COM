import React, { useState } from 'react';
import { Clock } from 'lucide-react';

interface CallDurationTimerProps {
  durationSeconds: number;
  className?: string;
}

export const CallDurationTimer: React.FC<CallDurationTimerProps> = ({
  durationSeconds,
  className = '',
}) => {
  const [showDetailed, setShowDetailed] = useState(false);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const pad = (n: number) => n.toString().padStart(2, '0');

    if (hours > 0 || showDetailed) {
      return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    }
    return `${pad(minutes)}:${pad(seconds)}`;
  };

  return (
    <div
      onClick={() => setShowDetailed(!showDetailed)}
      title="Active Call Duration (Click to toggle format)"
      className={`flex items-center gap-2 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700/80 hover:border-slate-600 rounded-xl shadow-xs backdrop-blur-md cursor-pointer transition-all ${className}`}
    >
      {/* Active green pulse indicator */}
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
      </span>

      <Clock className="w-3.5 h-3.5 text-slate-400" />

      {/* Tabular Numerals formatted timer */}
      <div className="flex flex-col">
        <span className="font-mono tabular-nums text-xs font-semibold text-slate-100 tracking-tight">
          {formatTime(durationSeconds)}
        </span>
      </div>
    </div>
  );
};
